import type { Metadata } from "next";
import { devData } from "@/lib/data/dev";
import { PROFILES } from "@/lib/data/profiles";
import PortalHero from "@/components/landing/dev-v2/PortalHero";

export const metadata: Metadata = {
  title: devData.meta.title,
  description: devData.meta.description,
};

/**
 * Racine du site : la landing développeurs.
 *
 * Ce projet ne sert qu'une seule surface — dev.bnjteammaker.fr / .com — donc
 * la landing vit à `/` plutôt que sur une sous-route. Il n'y a plus de page
 * d'accueil séparée qui listerait plusieurs verticales.
 */
export default function Page() {
  return <PortalHero profiles={PROFILES.dev} />;
}
