import type { Metadata } from "next";
import { DM_Sans } from "next/font/google";
import "./globals.css";

// Une seule famille : la landing n'utilise que DM Sans. Archivo et Work Sans
// ne servaient qu'aux surfaces supprimées — les charger coûterait deux
// téléchargements de police pour rien.
const dmSans = DM_Sans({
  variable: "--font-dm-sans",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "BNJ Team Maker",
  description: "Talents francophones qualifiés pour scaler votre équipe rapidement.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="fr"
      className={dmSans.variable}
      style={{ fontFamily: "var(--font-dm-sans, 'DM Sans', system-ui, sans-serif)" }}
    >
      <body
        className="min-h-full flex flex-col bg-[#08050f] text-[#f0ecf8] antialiased"
        style={{ fontFamily: "inherit" }}
      >
        {children}
      </body>
    </html>
  );
}
