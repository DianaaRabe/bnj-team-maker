# BNJ Team Maker — Landing développeurs

Landing page unique servie sur **dev.bnjteammaker.fr** et **dev.bnjteammaker.com**.

Next.js 16 (App Router) + React 19 + Tailwind CSS v4, en TypeScript.

---

## ⚠ À faire en premier : révoquer les clés

Les identifiants Cloudflare présents dans `.env.local` **ont été transmis en clair
dans une conversation**. Ils doivent être considérés comme compromis.

Avant toute mise en production :

1. Cloudflare → *My Profile* → *API Tokens* → révoquer le token existant.
2. Cloudflare → *R2* → révoquer l'Access Key / Secret Access Key.
3. Régénérer, puis remplacer les valeurs dans `.env.local`.

Idem pour `CAL_API_KEY`, transmise dans les mêmes conditions.

`.env.local` est couvert par `.gitignore` (`.env*`) : il n'est jamais versionné.

---

## Démarrer

```bash
npm install
npm run dev
```

→ http://localhost:3000

```bash
npm run build   # build de production
npm start       # sert le build
npm run lint
```

---

## Variables d'environnement

Copier `.env.example` vers `.env.local` et renseigner les valeurs.

| Variable | Rôle | Obligatoire |
|---|---|---|
| `CAL_API_KEY` | Clé serveur Cal.com. Lit les créneaux réels. **Jamais exposée au navigateur.** | oui — sans elle le panneau de réservation affiche son état d'erreur |
| `NEXT_PUBLIC_CAL_USERNAME` | Identifiant public Cal.com | oui |
| `CLOUDFLARE_ACCOUNT_ID` | Compte Cloudflare (DNS / R2) | non — infra uniquement |
| `CLOUDFLARE_API_TOKEN` | Token API Cloudflare | non — infra uniquement |
| `R2_ACCESS_KEY_ID` / `R2_SECRET_ACCESS_KEY` / `R2_S3_ENDPOINT` | Stockage R2. **Non utilisé par la landing aujourd'hui.** | non |

---

## Structure

```
app/
  page.tsx            La landing (racine du site)
  layout.tsx          Polices + coquille HTML
  globals.css         Thème « portail » — tout est préfixé .p-
  api/cal/slots/      Créneaux Cal.com, côté serveur (protège la clé API)
components/landing/dev-v2/
  PortalHero.tsx      Assemble toute la page
  CostSimulator.tsx   Simulateur d'économies (hero)
  FloatingTech.tsx    Icônes de technos animées (gsap)
  PainGrid.tsx        « Le constat »
  ProcessSpire.tsx    Entonnoir en 5 étapes
  CompareTable.tsx    Tableau comparatif (section claire)
  LoveWall.tsx        Mur des retours  ⚠ contenu de démonstration
  Faq.tsx             FAQ en accordéon
  BookingArc.tsx      Section de réservation
  BookingPanel.tsx    Calendrier + créneaux, branché sur Cal.com
lib/
  cal.ts              Config Cal.com (fuseau, durée, event type)
  constants.ts        Marque, FAQ, étapes du process
  data/dev.ts         Copie de la page
  data/profiles.ts    Profils du vivier
  types.ts
```

### Contenu à remplacer avant mise en ligne

`LoveWall.tsx` affiche des témoignages **fictifs** (noms, entreprises et propos
inventés), signalés dans l'interface par un bandeau « Exemples de mise en page ».
BNJ ne dispose d'aucun témoignage client réel à ce jour. Remplacer les données
et **retirer le bandeau en même temps** — pas avant.

---

## Cal.com

Le panneau de réservation lit les vrais créneaux via `/api/cal/slots`, qui
interroge Cal.com côté serveur. La clé API ne descend jamais dans le navigateur.

Tout est affiché en **heure de Paris**, quel que soit le fuseau du visiteur.

Un clic sur un créneau ouvre la modale Cal.com **directement sur ce créneau** :
l'utilisateur n'a pas à le resélectionner.

Réglages qui vivent dans le **dashboard Cal.com**, pas dans ce code :

- le titre du rendez-vous ;
- les champs du formulaire (téléphone, type de profil recherché…) →
  *Event Types* → l'événement → *Advanced* → *Booking questions*.

---

## Déploiement — Netlify

Le projet est un Next.js standard, sans base de données ni authentification.
`netlify.toml` porte déjà la commande de build et la version de Node.

1. Créer le site sur Netlify (dépôt Git ou dépôt de l'archive).
2. Renseigner `CAL_API_KEY` et `NEXT_PUBLIC_CAL_USERNAME` dans
   *Site configuration* → *Environment variables*. `.env.local` n'est pas
   déployé.
3. Brancher `dev.bnjteammaker.fr` et `dev.bnjteammaker.com` —
   procédure complète dans **`docs/cloudflare-dns.md`**.

Le rendu serveur doit rester actif : `/api/cal/slots` en dépend pour garder
`CAL_API_KEY` hors du navigateur. Ne pas basculer le site en export statique.

### Si vous zippez le projet

Exclure de l'archive : `node_modules/`, `.next/`, `tsconfig.tsbuildinfo`, et
**`.env.local`** si l'archive part chez un tiers.
