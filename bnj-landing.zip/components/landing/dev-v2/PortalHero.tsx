"use client";

import { useState } from "react";
import Link from "next/link";
import type { TalentProfile } from "@/lib/data/profiles";
import { BRAND } from "@/lib/constants";
import CostSimulator from "./CostSimulator";
import FloatingTech from "./FloatingTech";
import PainGrid from "./PainGrid";
import CompareTable from "./CompareTable";
import LoveWall from "./LoveWall";
import ProcessSpire from "./ProcessSpire";
import Faq from "./Faq";
import BookingArc from "./BookingArc";

/* ─────────────────────────────────────────────────────────────────────
   Hero « portail ». Reproduction de la référence fournie.

   La signature tient à une seule chose : le dôme lumineux est OCCULTÉ par
   l'arête haute du panneau. La zone lumineuse est en overflow-hidden et son
   bord bas coïncide exactement avec le haut du panneau ; chaque couche est
   ancrée en bas avec un décalage négatif, donc seule sa moitié supérieure
   est visible. C'est ce que lit l'œil comme un lever de soleil.

   Empilement, du fond vers l'avant :
     halo (diffusion) → ailes (nappe horizontale) → cœur (dôme chaud)
     → filament (trait posé sur l'arête) → panneau → fuite de lumière.
   ───────────────────────────────────────────────────────────────────── */

/**
 * Chaque entrée doit viser une section qui existe RÉELLEMENT dans la page.
 * Les ancres #profils, #tarifs et #blog pointaient dans le vide : « Blog »
 * n'existe pas sur cette surface et a été retiré, les deux autres sont
 * recalées sur le vivier et le tableau comparatif.
 */
const NAV = [
  { label: "Profils", href: "#profils" },
  { label: "Tarifs", href: "#comparatif" },
  { label: "Process", href: "#process" },
  { label: "FAQ", href: "#faq" },
];

/** Poussière d'étoiles — positions fixes, jamais aléatoires : le rendu
 *  serveur et le rendu client doivent coïncider. */
const STARS = [
  [12, 46, 1.6, 0.5], [19, 28, 1.1, 0.35], [26, 58, 1.3, 0.45], [31, 22, 1, 0.3],
  [35, 66, 1.5, 0.55], [39, 38, 1.1, 0.4], [43, 71, 1.2, 0.5], [46, 18, 1.4, 0.45],
  [49, 61, 1, 0.35], [52, 33, 1.6, 0.6], [55, 74, 1.2, 0.45], [58, 25, 1.1, 0.35],
  [62, 55, 1.4, 0.5], [66, 41, 1, 0.3], [69, 68, 1.3, 0.45], [73, 30, 1.5, 0.5],
  [77, 59, 1.1, 0.35], [81, 44, 1.2, 0.4], [85, 24, 1, 0.3], [88, 63, 1.4, 0.45],
  [8, 62, 1.2, 0.3], [15, 72, 1, 0.28], [92, 40, 1.1, 0.3], [70, 15, 1.2, 0.32],
  [28, 12, 1, 0.26], [60, 12, 1.1, 0.3], [40, 52, 0.9, 0.4], [50, 48, 0.9, 0.35],
] as const;

function Portal() {
  return (
    <div aria-hidden className="pointer-events-none relative h-[260px] sm:h-[340px] md:h-[420px]">
      {/* Diffusion ambiante — HORS de la zone rognée, donc libre de monter
          derrière l'accroche et de s'éteindre par sa propre courbe. */}
      <div className="p-ambient absolute bottom-0 left-1/2 h-[980px] w-[1600px] -translate-x-1/2" />

      {/* Zone rognée : le bord bas coïncide avec l'arête du panneau. */}
      <div className="p-portal absolute inset-0 overflow-hidden">
      {/* Anneaux concentriques — centrés sur l'arête, moitié haute visible */}
      {[640, 940, 1280].map((d) => (
        <div
          key={d}
          style={{ height: d, width: d }}
          className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 rounded-full border border-white/[0.055]"
        />
      ))}

      {/* Poussière d'étoiles */}
      {STARS.map(([l, t, s, o], i) => (
        <span
          key={i}
          style={{ left: `${l}%`, top: `${t}%`, height: s, width: s, opacity: o }}
          className="absolute rounded-full bg-white"
        />
      ))}

      {/* Nappe horizontale le long de l'arête */}
      <div className="p-wings absolute bottom-[-200px] left-1/2 h-[400px] w-[1900px] -translate-x-1/2" />
      {/* Dôme chaud */}
      <div className="p-core absolute bottom-[-245px] left-1/2 h-[490px] w-[490px] -translate-x-1/2 rounded-full" />
      {/* Liseré d'arc */}
      <div className="p-rim absolute bottom-[-215px] left-1/2 h-[430px] w-[430px] -translate-x-1/2 rounded-full" />
      {/* Noyau incandescent */}
      <div className="p-core-hot absolute bottom-[-110px] left-1/2 h-[220px] w-[260px] -translate-x-1/2 rounded-full" />
      {/* Filament posé sur l'arête */}
      <div className="p-filament absolute bottom-[-7px] left-1/2 h-[16px] w-[1020px] -translate-x-1/2" />
      </div>

      {/* Icônes technos — hors de la zone rognée, sinon le masque du haut
          les effacerait et le bord bas les couperait net. */}
      <FloatingTech />
    </div>
  );
}

/* ── Panneau applicatif : même géométrie 3 colonnes que la référence,
      la vidéo est remplacée par le vivier de profils. ──────────────── */

const SIDEBAR = [
  { label: "Développeurs", active: true },
  { label: "Tous les profils", active: false },
  { label: "Disponibles", active: false },
  { label: "Favoris", active: false },
];

function ProfilePanel({ profiles }: { profiles: TalentProfile[] }) {
  const [selected, setSelected] = useState(0);
  const active = profiles[selected];

  return (
    <div className="p-panel relative mx-auto h-[430px] max-w-[1210px] overflow-hidden rounded-t-[16px] sm:h-[520px]">
      {/* Fuite de lumière à travers le haut du panneau */}
      <div aria-hidden className="p-bleed pointer-events-none absolute inset-x-0 top-0 h-[260px]" />

      <div className="relative grid h-full grid-cols-1 md:grid-cols-[212px_minmax(0,1fr)] lg:grid-cols-[212px_minmax(0,1fr)_276px]">
        {/* Colonne 1 — recherche + navigation */}
        <div className="hidden border-r border-white/[0.07] p-4 md:block">
          <div className="flex items-center gap-2 rounded-lg border border-white/[0.08] bg-white/[0.04] px-2.5 py-2">
            <svg viewBox="0 0 16 16" className="h-3.5 w-3.5 flex-shrink-0" fill="none" aria-hidden>
              <circle cx="7" cy="7" r="4.6" stroke="rgba(255,255,255,0.5)" strokeWidth="1.4" />
              <path d="M10.6 10.6 14 14" stroke="rgba(255,255,255,0.5)" strokeWidth="1.4" strokeLinecap="round" />
            </svg>
            <span className="text-[0.76rem] text-white/40">Rechercher un profil…</span>
            <span className="ml-auto rounded border border-white/10 px-1 py-0.5 text-[0.6rem] text-white/35">⌘K</span>
          </div>

          <nav className="mt-5 space-y-0.5">
            {SIDEBAR.map((s) => (
              <span
                key={s.label}
                className={`flex items-center gap-2.5 rounded-md px-2.5 py-[7px] text-[0.8rem] ${
                  s.active ? "bg-white/[0.06] text-[#d8b4fe]" : "text-white/55"
                }`}
              >
                <span
                  className={`h-1.5 w-1.5 rounded-full ${s.active ? "bg-[#c069ee]" : "bg-white/25"}`}
                />
                {s.label}
              </span>
            ))}
          </nav>

          <p className="mt-6 px-2.5 text-[0.62rem] uppercase tracking-[0.1em] text-white/25">
            Épinglés
          </p>
          <div className="mt-2 space-y-0.5">
            {profiles.map((p, i) => (
              <button
                key={p.id}
                onClick={() => setSelected(i)}
                className={`block w-full rounded-md px-2.5 py-[7px] text-left text-[0.78rem] transition-colors ${
                  i === selected ? "bg-white/[0.05] text-white/90" : "text-white/45 hover:text-white/75"
                }`}
              >
                {p.name}
              </button>
            ))}
          </div>
        </div>

        {/* Colonne 2 — la fiche */}
        <div className="min-w-0 overflow-hidden p-5 sm:p-7">
          <div className="flex items-center gap-2 text-[0.72rem] text-white/40">
            <span className="h-3 w-[2px] rounded bg-[#c069ee]" />
            Vivier BNJ · {profiles.length} profils affichés sur 8 000+
          </div>

          <div className="mt-4 flex items-start gap-4">
            <div className="h-14 w-14 flex-shrink-0 overflow-hidden rounded-xl border border-white/10">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={active.photo}
                alt=""
                aria-hidden
                className="h-full w-full object-cover"
                style={{ filter: "blur(4px)", transform: "scale(1.25)" }}
              />
            </div>
            <div className="min-w-0">
              <h2 className="text-[1.15rem] font-semibold tracking-[-0.02em] text-white">
                {active.name}
              </h2>
              <p className="mt-0.5 text-[0.82rem] text-white/50">{active.role}</p>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <span
                  className={`rounded-full border px-2 py-0.5 text-[0.66rem] ${
                    active.availability === "Disponible"
                      ? "border-[#c069ee]/40 bg-[#c069ee]/10 text-[#d8b4fe]"
                      : "border-white/15 bg-white/[0.04] text-white/50"
                  }`}
                >
                  {active.availability}
                </span>
                <span className="rounded-full border border-[#feb527]/35 bg-[#feb527]/10 px-2 py-0.5 text-[0.66rem] font-semibold text-[#feb527]">
                  {active.tjm}
                </span>
                <span className="text-[0.7rem] text-white/40">{active.experience}</span>
              </div>
            </div>
          </div>

          <ul className="mt-5 space-y-2.5">
            {active.highlights.map((h, i) => (
              <li key={i} className="flex gap-2.5 text-[0.82rem] leading-6 text-white/60">
                <span aria-hidden className="mt-[11px] h-px w-2.5 flex-shrink-0 bg-[#c069ee]" />
                {h}
              </li>
            ))}
          </ul>

          <div className="mt-5 flex flex-wrap gap-1.5">
            {active.skills.slice(0, 8).map((s) => (
              <span
                key={s}
                className="rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-1 text-[0.7rem] text-white/60"
              >
                {s}
              </span>
            ))}
          </div>
        </div>

        {/* Colonne 3 — disponibilités */}
        <div className="hidden border-l border-white/[0.07] p-5 lg:block">
          <div className="flex items-center justify-between">
            <p className="text-[0.85rem] font-semibold text-white/85">Disponibilités</p>
            <span className="text-[0.7rem] text-white/35">Avril 2026</span>
          </div>

          <div className="mt-4 grid grid-cols-7 gap-y-2 text-center text-[0.62rem] text-white/35">
            {["Lu", "Ma", "Me", "Je", "Ve", "Sa", "Di"].map((d) => (
              <span key={d}>{d}</span>
            ))}
          </div>
          <div className="mt-1.5 grid grid-cols-7 gap-y-1.5 text-center text-[0.7rem]">
            {Array.from({ length: 30 }, (_, i) => i + 1).map((n) => {
              const free = n >= 6 && n <= 24 && n % 7 !== 0 && n % 7 !== 6;
              const today = n === 8;
              return (
                <span
                  key={n}
                  className={`mx-auto flex h-6 w-6 items-center justify-center rounded-md ${
                    today
                      ? "bg-[#590293] font-semibold text-white"
                      : free
                        ? "text-white/70"
                        : "text-white/20"
                  }`}
                >
                  {n}
                </span>
              );
            })}
          </div>

          <div className="mt-5 rounded-lg border border-white/[0.08] bg-white/[0.03] p-3">
            <p className="text-[0.7rem] text-white/45">Démarrage possible</p>
            <p className="mt-1 text-[0.95rem] font-semibold text-white">Sous 7 jours</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function PortalHero({ profiles }: { profiles: TalentProfile[] }) {
  return (
    <div data-surface="portal" className="relative min-h-screen overflow-hidden">
      {/* ── Navigation ── */}
      <header className="relative z-20 mx-auto flex max-w-[1400px] items-center justify-between gap-4 px-5 py-5 md:px-8">
        <Link href="/" className="flex items-center gap-2.5">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={BRAND.logo.white} alt="BNJ Team Maker" style={{ height: "1.9rem", width: "auto" }} />
        </Link>

        <nav className="p-navpill hidden items-center gap-0.5 rounded-full p-1.5 lg:flex">
          {NAV.map((n) => (
            <a key={n.label} href={n.href} className="p-navlink rounded-full px-4 py-2 text-[0.9rem]">
              {n.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href={BRAND.calendly}
            target="_blank"
            rel="noopener noreferrer"
            className="p-cta rounded-lg px-4 py-2.5 text-[0.88rem] font-medium"
          >
            Réserver un appel
          </a>
        </div>
      </header>

      {/* ── Accroche + simulateur, côte à côte ──
          Deux colonnes à partir de xl seulement : en dessous, la colonne
          gauche devient trop étroite pour un titre de cette taille. */}
      <div className="relative z-10 mx-auto grid max-w-[1300px] items-center gap-10 px-5 pt-12 text-center md:pt-16 xl:grid-cols-[minmax(0,1fr)_430px] xl:gap-14 xl:text-left">
        <div className="min-w-0">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/[0.11] bg-white/[0.05] px-4 py-2 text-[0.86rem] text-white/85">
            <svg viewBox="0 0 16 16" className="h-3.5 w-3.5 flex-shrink-0" fill="none" aria-hidden>
              <path
                d="M8 1.5 9.3 5.9 13.7 7.2 9.3 8.5 8 12.9 6.7 8.5 2.3 7.2 6.7 5.9Z"
                fill="#c069ee"
              />
              <path
                d="M12.8 11.4 13.4 13.2 15.2 13.8 13.4 14.4 12.8 16.2 12.2 14.4 10.4 13.8 12.2 13.2Z"
                fill="#c069ee"
                opacity="0.65"
              />
            </svg>
            Nouveau : 8 000+ développeurs francophones qualifiés
          </span>

          {/* Pas de nowrap : en deux colonnes le titre a moins de largeur et
              doit pouvoir passer sur deux lignes. */}
          <h1 className="mt-7 text-[2.4rem] font-semibold leading-[1.04] tracking-[-0.035em] text-white sm:text-[3.4rem] md:text-[4.2rem] xl:text-[3.9rem]">
            Des développeurs qui livrent.
            <br />
            Sans exploser votre budget.
          </h1>

          <p className="mx-auto mt-5 max-w-[46ch] text-[1rem] text-white/55 md:text-[1.12rem] xl:mx-0">
            Des développeurs testés, francophones, disponibles sous 7 jours.
          </p>

          <div className="mt-8 flex justify-center xl:justify-start">
            {/* Glow néon animé — voir .p-formglow dans globals.css. */}
            <div className="p-formglow relative inline-block rounded-lg">
              <a
                href={BRAND.calendly}
                target="_blank"
                rel="noopener noreferrer"
                className="p-cta relative z-10 inline-flex items-center gap-2 rounded-lg px-6 py-3.5 text-[0.9rem] font-medium"
              >
                Réserver un appel
              </a>
            </div>
          </div>
        </div>

        {/* Simulateur — à droite du titre à partir de xl */}
        <div className="mt-2 xl:mt-0">
          <CostSimulator />
        </div>
      </div>

      {/* ── Portail + panneau ──
          Le portail est pleine largeur : enfermé dans le padding, il se lisait
          comme un rectangle violet à bords francs au format téléphone. Seul le
          panneau garde sa gouttière. */}
      <div id="profils" className="relative z-10 mt-2 md:mt-6">
        <Portal />
        <div className="px-4">
          <ProfilePanel profiles={profiles} />
        </div>
      </div>

      <PainGrid />
      <ProcessSpire />
      <CompareTable />
      <LoveWall />
      <Faq />
      <BookingArc />
    </div>
  );
}
